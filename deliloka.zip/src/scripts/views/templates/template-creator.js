const createIconLikeTemplate = () => '<i class="justify-center material-symbols-rounded fill red">favorite</i>';

const createIconUnlikeTemplate = () => '<i class="justify-center material-symbols-rounded">favorite</i>';

export {
  createIconLikeTemplate,
  createIconUnlikeTemplate
};
